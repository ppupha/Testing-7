CREATE TABLE data 
(
	value TEXT
);

INSERT INTO data
VALUES ('Hello, memory!')